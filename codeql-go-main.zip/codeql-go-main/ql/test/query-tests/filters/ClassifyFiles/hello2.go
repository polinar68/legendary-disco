// Code generated from stuff; DO NOT EDIT.

package main

import "fmt"

func main2() {
	fmt.Println("Hello, world!")
}
