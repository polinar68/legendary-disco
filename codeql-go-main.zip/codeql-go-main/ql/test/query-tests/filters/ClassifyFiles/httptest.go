package main

import "net/http/httptest"

func setup(server *httptest.Server) {}
