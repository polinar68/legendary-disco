package main

func main() {
	x := 42
	x = x // NOT OK
}
