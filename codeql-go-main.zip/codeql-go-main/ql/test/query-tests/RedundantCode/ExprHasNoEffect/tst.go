// +build linux

package main

func dostuff() {
	// nothing to do on Linux
}
