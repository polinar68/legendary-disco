package main

func (w *counter) resetGood() {
	w.val = 0 // OK
}
