// +build linux, amd64

package main

const ptrsize = 8
