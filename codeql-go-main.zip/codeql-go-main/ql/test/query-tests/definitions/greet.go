package main

import "fmt"

func greet2() {
	fmt.Println("Hello world!")
}
