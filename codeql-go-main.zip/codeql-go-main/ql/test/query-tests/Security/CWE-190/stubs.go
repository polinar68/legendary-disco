package main

func encryptBuffer(buf []byte) ([]byte, error) {
	return buf, nil
}
