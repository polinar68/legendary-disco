package main

const HASH = "#"

func someUrl() string { return "semmle.com" }

// placeholder
func isValidRedirect(s string) bool {
	return true
}
