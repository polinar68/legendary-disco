package main

func use(vars ...interface{}) {

}
