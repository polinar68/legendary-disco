package main

// autoformat-ignore (gofmt chokes on invalid programs)

// Example file with a syntax error to demonstrate use of consistency queries

This is not a valid Go program
