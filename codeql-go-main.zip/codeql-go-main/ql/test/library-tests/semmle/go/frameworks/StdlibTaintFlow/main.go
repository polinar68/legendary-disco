package main

func main()                      {}
func sink(id int, v interface{}) {}

func link(from interface{}, into interface{}) {}

func newSource(id int) interface{} {
	return nil
}
