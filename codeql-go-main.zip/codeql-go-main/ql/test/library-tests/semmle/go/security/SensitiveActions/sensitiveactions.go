package main

func loginfo() {}

func login() {}

func auth() {}

func author() {}

func test() {
	loginfo()
	login()
	auth()
	author()
}
