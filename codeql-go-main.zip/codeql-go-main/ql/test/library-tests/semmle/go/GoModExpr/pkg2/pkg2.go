package pkg2

import (
	"fmt"

	"github.com/Masterminds/squirrel"
	"github.com/gorilla/mux"
	"github.com/sirupsen/logrus"
)

func useDeps() {

}
