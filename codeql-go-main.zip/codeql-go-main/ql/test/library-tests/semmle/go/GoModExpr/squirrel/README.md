This is a simple stub for https://github.com/Masterminds/squirrel, strictly for use in query testing.

See the LICENSE file in this folder for information about the licensing of the original library.
