This is the go.mod and go.sum files from  https://github.com/securekey/fabric-snaps, strictly for use in query testing.

See the LICENSE file in this folder for information about the licensing of the original code.
