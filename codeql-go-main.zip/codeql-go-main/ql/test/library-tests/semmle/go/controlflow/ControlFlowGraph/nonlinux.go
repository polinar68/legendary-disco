// +build !linux

package main

const linux = false
