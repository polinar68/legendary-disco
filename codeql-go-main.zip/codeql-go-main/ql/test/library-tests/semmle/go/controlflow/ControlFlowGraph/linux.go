// +build linux

package main

const linux = true
