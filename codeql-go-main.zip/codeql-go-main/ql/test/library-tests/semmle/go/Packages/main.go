package main

import (
	"fmt"

	"github.com/nonexistent-test-pkg"
)

func main() {
	pkg.Foo()
	fmt.Println("")
}
