package main

func absGood(x int) int {
	if x >= 0 {
		return x
	} else {
		return -x
	}
}
