package main

func shift(base int32) int32 {
	return base << 40
}

var x1 = shift(1)
