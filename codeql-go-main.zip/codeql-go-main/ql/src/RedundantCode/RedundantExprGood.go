package main

func avgGood(x, y float64) float64 {
	return (x + y) / 2
}
