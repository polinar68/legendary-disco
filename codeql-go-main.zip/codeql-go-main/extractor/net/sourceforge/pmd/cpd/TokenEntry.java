package net.sourceforge.pmd.cpd;

/*
 * This is a stub definition for pmd's TokenEntry class
 * including only the API used by the GoLanguage class.
 */

public class TokenEntry {
  public TokenEntry(String image, String tokenSrcID, int beginLine, int beginColumn, int endLine, int endColumn) {
  }
}
