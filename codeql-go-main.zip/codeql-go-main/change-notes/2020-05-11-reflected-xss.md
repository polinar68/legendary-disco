lgtm,codescanning
* The query "Reflected cross-site scripting" has been improved to recognize more cases where the
  value should be considered to be safe, which should lead to fewer false positive results.
