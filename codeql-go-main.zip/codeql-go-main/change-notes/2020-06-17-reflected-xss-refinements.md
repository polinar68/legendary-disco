lgtm,codescanning
* The query "Reflected cross-site scripting" has been improved to more correctly determine whether
  an HTML mime type will be sniffed, which should lead to more accurate results.
