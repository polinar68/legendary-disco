lgtm,codescanning
* Basic support for the [Go-restful](https://github.com/emicklei/go-restful) HTTP library has been added, which
  may lead to more results from the security queries.
* Basic support for the [Gorm](https://github.com/go-gorm/gorm) ORM library has been added (specifically, its SQL statement building facilities), which
  may lead to more results from the security queries.
* Basic support for the [Sqlx](https://github.com/jmoiron/sqlx) database access library has been added, which
  may lead to more results from the security queries.
* Basic support for the [Json-iterator](https://github.com/json-iterator/go) JSON library has been added, which
  may lead to more results from the security queries.
