lgtm,codescanning
* Modeling of the `go.mongodb.org/mongo-driver/mongo` package has been added, which may lead to more
  results from the security queries.
