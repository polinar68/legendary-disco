lgtm,codescanning
* Support for the [GORM](https://github.com/go-gorm/gorm) ORM library (specifically, its SQL
  statement building facilities) has been improved, which may lead to more results from the
  security queries.
