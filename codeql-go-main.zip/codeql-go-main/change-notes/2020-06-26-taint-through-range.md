lgtm,codescanning
* Taint tracking through `range` statements has been improved, which may cause more results from the security queries.
