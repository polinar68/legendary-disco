lgtm,codescanning
* The queries "Uncontrolled data used in path expression" and "Arbitrary file write during zip
  extraction ("zip slip")" have been improved to recognize more file APIs, which may lead to more
  alerts.
