lgtm,codescanning
* A bug has been fixed that caused the autobuilder to not work on repositories with a `file://` URL as `origin`.
